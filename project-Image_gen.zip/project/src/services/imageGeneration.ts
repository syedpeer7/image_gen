import { generateImageWithStabilityAI, StabilityAIError } from './api/stabilityAI';
import type { ImageGenerationOptions } from './api/types';

export class ImageGenerationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ImageGenerationError';
  }
}

export async function generateImage(prompt: string, options?: ImageGenerationOptions): Promise<string> {
  if (!prompt.trim()) {
    throw new ImageGenerationError('Please provide a description for your artwork');
  }

  try {
    return await generateImageWithStabilityAI(prompt, options);
  } catch (error) {
    console.error('Error generating image:', error);
    
    if (error instanceof StabilityAIError) {
      throw new ImageGenerationError(error.message);
    }

    throw new ImageGenerationError('Failed to generate image. Please try again later.');
  }
}