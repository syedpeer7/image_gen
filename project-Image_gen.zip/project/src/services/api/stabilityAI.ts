import { API_CONFIG } from './config';
import type { StabilityAIResponse, ErrorResponse, ImageGenerationOptions } from './types';

const DEFAULT_OPTIONS: Required<ImageGenerationOptions> = {
  height: 1024,
  width: 1024,
  steps: 30,
  samples: 1,
  cfgScale: 7,
};

export class StabilityAIError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'StabilityAIError';
  }
}

export async function generateImageWithStabilityAI(
  prompt: string,
  options: ImageGenerationOptions = {}
): Promise<string> {
  if (!prompt.trim()) {
    throw new StabilityAIError('Prompt cannot be empty');
  }

  const mergedOptions = { ...DEFAULT_OPTIONS, ...options };
  const apiUrl = `${API_CONFIG.STABILITY_AI.BASE_URL}/${API_CONFIG.STABILITY_AI.MODEL}/text-to-image`;

  try {
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        Authorization: `Bearer ${API_CONFIG.STABILITY_AI.API_KEY}`,
      },
      body: JSON.stringify({
        text_prompts: [{ text: prompt, weight: 1 }],
        cfg_scale: mergedOptions.cfgScale,
        height: mergedOptions.height,
        width: mergedOptions.width,
        steps: mergedOptions.steps,
        samples: mergedOptions.samples,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json() as ErrorResponse;
      throw new StabilityAIError(
        errorData.message || `API request failed with status ${response.status}`
      );
    }

    const result = await response.json() as StabilityAIResponse;
    
    if (!Array.isArray(result.artifacts) || result.artifacts.length === 0) {
      throw new StabilityAIError('No image data received from the API');
    }

    const artifact = result.artifacts[0];
    if (!artifact.base64) {
      throw new StabilityAIError('Invalid image data received from the API');
    }

    return artifact.base64;
  } catch (error) {
    if (error instanceof StabilityAIError) {
      throw error;
    }

    throw new StabilityAIError(
      error instanceof Error 
        ? error.message 
        : 'An unexpected error occurred while generating the image'
    );
  }
}