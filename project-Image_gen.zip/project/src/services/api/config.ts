export const API_CONFIG = {
  STABILITY_AI: {
    BASE_URL: 'https://api.stability.ai/v1/generation',
    MODEL: 'stable-diffusion-xl-1024-v1-0',
    API_KEY: 'sk-03pyu5nJ44cFbLuLgA7YOL9pNyyUDifPVawq4GPlpy0IkfCm',
  }
};