export interface StabilityAIResponse {
  artifacts: Array<{
    base64: string;
    seed: number;
    finishReason: string;
  }>;
}

export interface ErrorResponse {
  message: string;
  name?: string;
}

export interface ImageGenerationOptions {
  height?: number;
  width?: number;
  steps?: number;
  samples?: number;
  cfgScale?: number;
}