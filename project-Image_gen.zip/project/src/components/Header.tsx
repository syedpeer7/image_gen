import React from 'react';
import { Palette, ImagePlus, Calendar, LibraryBig } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <Palette className="w-8 h-8 text-indigo-600" />
            <span className="text-xl font-bold">Digital Art Gallery</span>
          </div>
          <nav className="flex items-center gap-8">
            <a href="#generate" className="flex items-center gap-2 text-indigo-600 hover:text-indigo-800">
              <ImagePlus className="w-5 h-5" />
              Generate
            </a>
            <a href="#exhibitions" className="flex items-center gap-2 text-indigo-600 hover:text-indigo-800">
              <Calendar className="w-5 h-5" />
              Exhibitions
            </a>
            <a href="#collections" className="flex items-center gap-2 text-indigo-600 hover:text-indigo-800">
              <LibraryBig className="w-5 h-5" />
              Collections
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
}