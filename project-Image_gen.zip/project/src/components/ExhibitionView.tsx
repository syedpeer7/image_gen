import React from 'react';
import { X } from 'lucide-react';
import { ArtworkCard } from './ArtworkCard';
import type { Exhibition } from '../types';

interface ExhibitionViewProps {
  exhibition: Exhibition;
  onClose: () => void;
  onDelete: (id: string) => void;
  onLike: (id: string) => void;
}

export function ExhibitionView({ exhibition, onClose, onDelete, onLike }: ExhibitionViewProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-7xl w-full max-h-[90vh] overflow-y-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-3xl font-bold">{exhibition.title}</h2>
            <p className="text-gray-600 mt-2">{exhibition.description}</p>
            <p className="text-sm text-gray-500 mt-1">
              {exhibition.startDate} - {exhibition.endDate}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full text-gray-500 hover:text-gray-700"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {exhibition.artworks.map((artwork) => (
            <ArtworkCard 
              key={artwork.id} 
              artwork={artwork}
              onDelete={onDelete}
              onLike={onLike}
            />
          ))}
        </div>
      </div>
    </div>
  );
}