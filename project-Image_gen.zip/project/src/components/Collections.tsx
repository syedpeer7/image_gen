import React from 'react';
import { ImageUploader } from './ImageUploader';
import { ArtworkCard } from './ArtworkCard';
import type { Artwork } from '../types';

interface CollectionsProps {
  onUpload: (artwork: Artwork) => void;
  artworks: Artwork[];
  onDelete: (id: string) => void;
  onLike: (id: string) => void;
}

export function Collections({ onUpload, artworks, onDelete, onLike }: CollectionsProps) {
  const handleUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const newArtwork: Artwork = {
        id: Date.now().toString(),
        title: file.name.replace(/\.[^/.]+$/, ""),
        description: "Uploaded artwork",
        imageUrl: e.target?.result as string,
        artist: "You",
        createdAt: new Date().toISOString(),
        likes: 0,
        isLiked: false,
      };
      onUpload(newArtwork);
    };
    reader.readAsDataURL(file);
  };

  return (
    <section className="mb-12" id="collections">
      <h2 className="text-3xl font-bold mb-6">My Collections</h2>
      <div className="mb-8">
        <ImageUploader onUpload={handleUpload} />
      </div>
      {artworks.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {artworks.map((artwork) => (
            <ArtworkCard 
              key={artwork.id} 
              artwork={artwork}
              onDelete={onDelete}
              onLike={onLike}
            />
          ))}
        </div>
      ) : (
        <p className="text-center text-gray-500 mt-8">
          No artworks in your collection yet. Upload some images to get started!
        </p>
      )}
    </section>
  );
}