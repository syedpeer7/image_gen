import React, { useState } from 'react';
import { Loader2, AlertCircle, RefreshCw } from 'lucide-react';
import { generateImageWithStabilityAI } from '../services/api/stabilityAI';
import type { Artwork } from '../types';

interface GenerateArtworkProps {
  onGenerate: (artwork: Artwork) => void;
}

export function GenerateArtwork({ onGenerate }: GenerateArtworkProps) {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setError('Please enter a description for your artwork');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const imageBase64 = await generateImageWithStabilityAI(prompt);
      const newArtwork: Artwork = {
        id: Date.now().toString(),
        title: prompt.slice(0, 50) + (prompt.length > 50 ? '...' : ''),
        description: prompt,
        imageUrl: `data:image/png;base64,${imageBase64}`,
        artist: 'AI Artist',
        createdAt: new Date().toISOString(),
      };
      onGenerate(newArtwork);
      setPrompt('');
    } catch (err) {
      setError(
        err instanceof Error 
          ? err.message 
          : 'Failed to generate image. Please try again.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleRetry = () => {
    setError(null);
    handleGenerate();
  };

  return (
    <section className="mb-12">
      <h2 className="text-3xl font-bold mb-6">Generate New Artwork</h2>
      <div className="bg-white p-8 rounded-lg shadow-lg">
        <div className="max-w-2xl mx-auto">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe your artwork idea... (e.g., 'A surreal landscape with floating islands and purple skies')"
            className="w-full h-32 p-4 border rounded-lg mb-4 focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
            disabled={isLoading}
          />
          
          {error && (
            <div className="flex items-center justify-between gap-2 text-red-500 mb-4 p-3 bg-red-50 rounded-lg">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <span>{error}</span>
              </div>
              <button
                onClick={handleRetry}
                className="flex items-center gap-1 text-sm text-red-600 hover:text-red-700"
              >
                <RefreshCw className="w-4 h-4" />
                Retry
              </button>
            </div>
          )}

          <button
            onClick={handleGenerate}
            disabled={isLoading || !prompt.trim()}
            className="w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition-colors disabled:bg-indigo-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Generating...
              </>
            ) : (
              'Generate Artwork'
            )}
          </button>
        </div>
      </div>
    </section>
  );
}