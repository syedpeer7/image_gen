import React, { useState } from 'react';
import { Calendar, ArrowRight } from 'lucide-react';
import { ExhibitionView } from './ExhibitionView';
import type { Exhibition } from '../types';

interface ExhibitionCardProps {
  exhibition: Exhibition;
  onDelete: (id: string) => void;
  onLike: (id: string) => void;
}

export function ExhibitionCard({ exhibition, onDelete, onLike }: ExhibitionCardProps) {
  const [showExhibition, setShowExhibition] = useState(false);

  return (
    <>
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-2xl font-bold mb-2">{exhibition.title}</h3>
        <p className="text-gray-600 mb-4">{exhibition.description}</p>
        <div className="flex items-center gap-2 text-gray-500 mb-4">
          <Calendar className="w-5 h-5" />
          <span>{exhibition.startDate} - {exhibition.endDate}</span>
        </div>
        <div className="grid grid-cols-3 gap-4 mb-4">
          {exhibition.artworks.slice(0, 3).map((artwork) => (
            <div key={artwork.id} className="aspect-square overflow-hidden rounded">
              <img
                src={artwork.imageUrl}
                alt={artwork.title}
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
              />
            </div>
          ))}
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-500">
            {exhibition.artworks.length} artwork{exhibition.artworks.length !== 1 ? 's' : ''} in exhibition
          </span>
          <button
            onClick={() => setShowExhibition(true)}
            className="flex items-center gap-2 text-indigo-600 hover:text-indigo-800"
          >
            View Exhibition <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
      {showExhibition && (
        <ExhibitionView
          exhibition={exhibition}
          onClose={() => setShowExhibition(false)}
          onDelete={onDelete}
          onLike={onLike}
        />
      )}
    </>
  );
}