import React from 'react';
import { ExhibitionCard } from './ExhibitionCard';
import type { Exhibition } from '../types';

interface CurrentExhibitionProps {
  exhibition: Exhibition;
  onDelete: (id: string) => void;
  onLike: (id: string) => void;
}

export function CurrentExhibition({ exhibition, onDelete, onLike }: CurrentExhibitionProps) {
  return (
    <section className="mb-12" id="exhibitions">
      <h2 className="text-3xl font-bold mb-6">Current Exhibition</h2>
      {exhibition.artworks.length > 0 ? (
        <ExhibitionCard 
          exhibition={exhibition}
          onDelete={onDelete}
          onLike={onLike}
        />
      ) : (
        <div className="bg-white rounded-lg shadow-lg p-6 text-center">
          <p className="text-gray-500">
            No artworks in the exhibition yet. Generate some artwork to see it displayed here!
          </p>
        </div>
      )}
    </section>
  );
}