import type { Artwork, Exhibition } from '../types';

export const sampleArtworks: Artwork[] = [
  {
    id: '1',
    title: 'Digital Dreams',
    description: 'An exploration of surreal digital landscapes',
    imageUrl: 'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4',
    artist: 'Sarah Chen',
    createdAt: '2024-03-15'
  },
  {
    id: '2',
    title: 'Neural Patterns',
    description: 'Abstract patterns generated through neural networks',
    imageUrl: 'https://images.unsplash.com/photo-1618005198919-d3d4b5a92ead',
    artist: 'David Miller',
    createdAt: '2024-03-14'
  }
];

export const sampleExhibition: Exhibition = {
  id: '1',
  title: 'Future Visions',
  description: 'A curated collection of AI-generated masterpieces',
  startDate: 'Mar 20, 2024',
  endDate: 'Apr 15, 2024',
  artworks: sampleArtworks
};