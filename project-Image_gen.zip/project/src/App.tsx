import React from 'react';
import { Header } from './components/Header';
import { GenerateArtwork } from './components/GenerateArtwork';
import { LatestCreations } from './components/LatestCreations';
import { CurrentExhibition } from './components/CurrentExhibition';
import { Collections } from './components/Collections';
import { useArtworkManager } from './hooks/useArtworkManager';

export default function App() {
  const {
    generatedArtworks,
    uploadedArtworks,
    handleNewArtwork,
    handleUploadedArtwork,
    handleDeleteArtwork,
    handleLikeArtwork,
    exhibition
  } = useArtworkManager();

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <GenerateArtwork onGenerate={handleNewArtwork} />
        <LatestCreations 
          artworks={generatedArtworks}
          onDelete={handleDeleteArtwork}
          onLike={handleLikeArtwork}
        />
        <CurrentExhibition 
          exhibition={exhibition}
          onDelete={handleDeleteArtwork}
          onLike={handleLikeArtwork}
        />
        <Collections 
          onUpload={handleUploadedArtwork}
          artworks={uploadedArtworks}
          onDelete={handleDeleteArtwork}
          onLike={handleLikeArtwork}
        />
      </main>
    </div>
  );
}