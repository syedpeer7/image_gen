import type { Artwork, Exhibition } from '../types';

export function createExhibition(artworks: Artwork[]): Exhibition {
  return {
    id: '1',
    title: 'Digital Art Exhibition',
    description: 'A showcase of AI-generated artworks and human creativity',
    startDate: new Date().toLocaleDateString(),
    endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString(),
    artworks
  };
}