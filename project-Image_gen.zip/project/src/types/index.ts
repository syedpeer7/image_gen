export interface Artwork {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  artist: string;
  createdAt: string;
  likes?: number;
  isLiked?: boolean;
}

export interface Exhibition {
  id: string;
  title: string;
  description: string;
  startDate: string;
  endDate: string;
  artworks: Artwork[];
}