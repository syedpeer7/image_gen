import { useState } from 'react';
import type { Artwork, Exhibition } from '../types';
import { createExhibition } from '../utils/exhibitionUtils';

export function useArtworkManager() {
  const [generatedArtworks, setGeneratedArtworks] = useState<Artwork[]>([]);
  const [uploadedArtworks, setUploadedArtworks] = useState<Artwork[]>([]);

  const handleNewArtwork = (artwork: Artwork) => {
    setGeneratedArtworks(prev => [{ ...artwork, likes: 0, isLiked: false }, ...prev]);
  };

  const handleUploadedArtwork = (artwork: Artwork) => {
    setUploadedArtworks(prev => [{ ...artwork, likes: 0, isLiked: false }, ...prev]);
  };

  const handleDeleteArtwork = (artworkId: string) => {
    setGeneratedArtworks(prev => prev.filter(art => art.id !== artworkId));
    setUploadedArtworks(prev => prev.filter(art => art.id !== artworkId));
  };

  const handleLikeArtwork = (artworkId: string) => {
    const updateArtworks = (artworks: Artwork[]) =>
      artworks.map(art =>
        art.id === artworkId
          ? {
              ...art,
              likes: (art.likes || 0) + (art.isLiked ? -1 : 1),
              isLiked: !art.isLiked,
            }
          : art
      );

    setGeneratedArtworks(updateArtworks);
    setUploadedArtworks(updateArtworks);
  };

  // Combine both generated and uploaded artworks for the exhibition
  const allArtworks = [...generatedArtworks, ...uploadedArtworks];
  const exhibition = createExhibition(allArtworks);

  return {
    generatedArtworks,
    uploadedArtworks,
    handleNewArtwork,
    handleUploadedArtwork,
    handleDeleteArtwork,
    handleLikeArtwork,
    exhibition
  };
}